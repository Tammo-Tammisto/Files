﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace ExceptionsPerformance
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new List<string>();

            for(var i = 0; i < Math.Pow(10, 6); i++)
            {
                if(i == 1 || i % 2 != 0)
                {
                    list.Add(i.ToString());
                }
                else
                {
                    list.Add(null);
                }
            }

            var watch = new Stopwatch();
            watch.Start();

            foreach(var s in list)
            {
                try
                {
                    var i = s.Length;
                }
                catch(Exception ex)
                {
                    var e = ex.Message;
                }
            }

            watch.Stop();
            Console.WriteLine(watch.Elapsed);

            watch.Restart();
            foreach(var s in list)
            {
                if(s == null)
                {
                    continue;
                }

                var i = s.Length;
            }

            watch.Stop();
            Console.WriteLine(watch.Elapsed);
        }
    }
}
