﻿using System;
using System.Data.SqlClient;
using System.IO;

namespace Exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            Method1();
        }

        static void Method1()
        {
            string s = null;

            WriteStringLength((string)null);
        }

        static void WriteStringLength(string s)
        {
            Console.WriteLine(s.Length);
        }
    }

    public abstract class BaseStream
    {
        // ... meetodid, omadused

        public abstract void Seek(int position);

        public abstract bool CanSeek { get; }
    }

    public class LiveStream : BaseStream
    {
        public override bool CanSeek { get { return false; } }

        public override void Seek(int position)
        {
            throw new InvalidOperationException("Live streams does not support seek operation");
        }
    }
}