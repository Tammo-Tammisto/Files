﻿using System;

namespace TryCatchFinally
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Töötav kood
                Console.WriteLine("Try");

                throw new ArgumentException("Argument s is incorrect", "s");
                string s = null;

                var i = s.Length;
            }            
            catch (NullReferenceException ex)
            {
                Console.WriteLine("NullReferenceException ex");
                Console.WriteLine(ex);
            }
            catch (Exception ex)
            {
                // Siia satume vea korral
                Console.WriteLine("Exception ex");
                Console.WriteLine(ex);

                //throw ex;
            }
            finally
            {
                // Läheb käima peale try/catch
                Console.WriteLine("Finally....");
            }
        }
    }
}
