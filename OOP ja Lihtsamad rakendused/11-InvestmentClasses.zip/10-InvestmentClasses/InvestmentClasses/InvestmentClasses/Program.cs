﻿using System;
using InvestmentClasses.Data;
using InvestmentClasses.Data.InMemoryData;
using InvestmentClasses.Domain;
using InvestmentClasses.Reporting;

namespace InvestmentClasses
{
    class Program
    {
        private static DataContext _dataContext = new DataContext();

        static void Main(string[] args)
        {
            IDataLoader loader = new InMemoryDataLoader();
            loader.LoadData(_dataContext);

            var account = _dataContext.Accounts.GetByName("LHV");
            var builder = new AccountStatementBuilder(account);
            var statement = builder.Build(DateTime.Now.Date.AddDays(-30), DateTime.Now.Date);

            // Kirjuta välja päis
            // Kirjuta välja kanded
        }
    }
}
