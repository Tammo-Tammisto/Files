﻿using System;

namespace PartyGeneralization
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new Person { FirstName = "John", LastName = "Smith", PersonalCode = "123" };
            var person2 = new Person { FirstName = "John", LastName = "Smith", PersonalCode = "456" };
            var company = new Company { Name = "Transferwise" };

            var invoicesWitNoParty = new[]
            {
                new InvoiceWithNoParty { InvoiceNo = "0001", Person = person },
                new InvoiceWithNoParty { InvoiceNo = "0002", Company = company }
            };

            var invoices = new[]
            {
                new Invoice { InvoiceNo = "0001", Customer = person },
                new Invoice { InvoiceNo = "0002", Customer = company },
                new Invoice { InvoiceNo = "0003", Customer = person2 }
            };

            foreach (var invoice in invoices)
            {
                Console.Write(invoice.InvoiceNo);
                Console.Write(" ");

                //---------------------------------------------------------
                //if(invoice.Person != null)
                //{
                //    Console.Write(invoice.Person.FirstName);
                //    Console.Write(" ");
                //    Console.WriteLine(invoice.Person.LastName);
                //}
                //else if(invoice.Company != null)
                //{
                //    Console.WriteLine(invoice.Company.Name);
                //}
                //---------------------------------------------------------
                Console.WriteLine(invoice.Customer.DisplayName);
                //---------------------------------------------------------
            }
        }
    }

    public class InvoiceWithNoParty
    {
        public int Id { get; set; }

        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public decimal Shipping { get; set; }

        public Person Person { get; set; }
        public Company Company { get; set; }
    }

    public class Invoice
    {
        public int Id { get; set; }

        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public decimal Shipping { get; set; }

        public Party Customer { get; set; }
    }

    public abstract class Party
    {
        public int Id { get; set; }

        public abstract string DisplayName { get; }
        public abstract string Code { get; }

        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int Discount { get; set; }
    }

    public class Person : Party
    {        
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PersonalCode { get; set; }

        public override string DisplayName
        {
            get
            {
                return FirstName + " " + LastName + " (" + PersonalCode + ")";
            }
        }

        public override string Code
        {
            get
            {
                return PersonalCode;
            }
        }
    }

    public class Company : Party
    {
        public string Name { get; set; }
        public string RegistrationNo { get; set; }

        public override string DisplayName
        {
            get
            {
                return Name;
            }
        }

        public override string Code
        {
            get
            {
                return RegistrationNo;
            }
        }
    }
}
