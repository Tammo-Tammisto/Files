﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestmentClasses.Domain
{
    public class Securable
    {
        public string Ticker { get; set; }
        public string Name { get; set; }
    }
}
