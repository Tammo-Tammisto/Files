﻿namespace InvestmentClasses.Data.InMemoryData
{
    public static class DealsLoader
    {
        public static void LoadDeals(DataContext context)
        {

        }
    }
}
