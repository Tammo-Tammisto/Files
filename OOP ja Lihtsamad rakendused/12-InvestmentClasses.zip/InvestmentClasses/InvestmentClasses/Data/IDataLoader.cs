﻿namespace InvestmentClasses.Data
{
    public interface IDataLoader
    {
        void LoadData(DataContext context);
    }
}
