﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestmentClasses.Reporting
{
    public class HtmlAccountStatementPrinter : IAccountStatementPrinter
    {
        private readonly AccountStatement _statement;
        private readonly string _fileName;

        public HtmlAccountStatementPrinter(AccountStatement statement, string fileName)
        {
            _statement = statement;
            _fileName = fileName;
        }

        public void Print()
        {
            if(!File.Exists(_fileName))
            {
                File.Delete(_fileName);
            }

            // Kasuta File.AppendAllText(), et kirjutada HTML välja
            File.AppendAllText(_fileName, "<html>");

            // Kirjuta konto ajalugu HTML-is välja

            File.AppendAllText(_fileName, "</html>");
        }
    }
}
