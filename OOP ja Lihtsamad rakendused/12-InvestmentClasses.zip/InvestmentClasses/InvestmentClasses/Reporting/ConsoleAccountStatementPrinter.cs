﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestmentClasses.Reporting
{
    public class ConsoleAccountStatementPrinter : IAccountStatementPrinter
    {
        private readonly AccountStatement _statement;

        public ConsoleAccountStatementPrinter(AccountStatement statement)
        {
            _statement = statement;
        }
        public void Print()
        {
            // Kasuta Console.Write, et konto väljavõte ekraanile kirjutada
        }
    }
}
