﻿using System;

namespace CalculatorLib
{
    public class Calculator
    {
        // Võtab vastu nupuvajutusi
        public void KeyPress(char key)
        {

        }

        // Tagastab tulemuse
        public decimal? Result
        {
            get
            {
                return null;
            }
        }
    }
}
